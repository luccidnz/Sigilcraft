import os
import string
import math
import uuid

from flask import Flask, request, send_from_directory, render_template
from PIL import Image, ImageDraw, ImageFont


"""Sigil Craft Generator Web App

This Flask application exposes a simple web interface for creating
customised sigils based on user‑supplied phrases. A sigil is drawn by
placing the unique letters from the phrase evenly around a circle (or
other shapes) and connecting them with a polyline. Colours and
shapes can be tweaked via the form on the front page.

Generated sigil images are stored in ``static/sigils`` with a
unique filename to avoid collisions. The user can download the
generated image directly from the result page.
"""

# Determine base directory relative to this file. This ensures
# generated sigils live inside the package even when the app is run
# from a different working directory.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Where generated images are saved. ``static/sigils`` is served
# automatically by Flask for downloading. Use an absolute path
# anchored at ``BASE_DIR`` so files are stored alongside the code.
STATIC_DIR = os.path.join(BASE_DIR, 'static')
SIGIL_DIR = os.path.join(STATIC_DIR, 'sigils')
os.makedirs(SIGIL_DIR, exist_ok=True)

# Create the Flask app. Provide ``static_folder`` and ``static_url_path``
# so Flask knows where to find static assets such as CSS and generated
# images. Without this, ``url_for('static', ...)`` might resolve
# incorrectly when the working directory changes.
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path='/static')


def generate_sigil(phrase: str,
                   shape: str = 'circle',
                   line_color: str = 'red',
                   letter_color: str = 'white',
                   size: int = 500,
                   radius: int = 180) -> Image.Image:
    """Create a sigil from a phrase.

    The phrase is normalised to uppercase and stripped of all
    non‑alphabetic characters. Duplicate letters are removed
    preserving order. Each remaining letter is placed equidistantly
    around a circle (or optionally another shape) and connected
    according to the selected pattern.

    Parameters
    ----------
    phrase : str
        The text to encode. Should contain at least one alphabetic
        character, or ``None`` is returned.
    shape : {'circle', 'polyline', 'star'}, optional
        The way in which the points are connected. A 'circle'
        connects every point and then returns to the starting point.
        A 'polyline' leaves the last point unconnected to the first.
        A 'star' connects every second point to create a star shape.
    line_color : str, optional
        Colour of the connecting lines. Accepts any colour name or
        hex string supported by Pillow.
    letter_color : str, optional
        Colour of the letters drawn around the circle.
    size : int, optional
        Size of the square output image in pixels.
    radius : int, optional
        Radius of the circle on which letters are placed.

    Returns
    -------
    PIL.Image.Image
        The generated sigil image, or ``None`` if no letters were
        extracted.
    """
    # Normalise phrase: uppercase and only alphabetic characters
    phrase = phrase.upper()
    phrase = ''.join(c for c in phrase if c in string.ascii_uppercase)
    if not phrase:
        return None

    # Remove duplicate letters, preserving original order
    seen = set()
    filtered = []
    for c in phrase:
        if c not in seen:
            seen.add(c)
            filtered.append(c)
    letters = filtered

    # Create a blank canvas
    img = Image.new('RGB', (size, size), color='black')
    draw = ImageDraw.Draw(img)

    # Choose font (fall back to default if system font unavailable)
    try:
        font = ImageFont.truetype('arial.ttf', 40)
    except Exception:
        font = ImageFont.load_default()

    # Compute positions for each letter
    n = len(letters)
    angle_step = 360.0 / n
    centre = (size / 2.0, size / 2.0)
    points = []
    for idx, letter in enumerate(letters):
        angle = math.radians(idx * angle_step - 90.0)
        x = centre[0] + radius * math.cos(angle)
        y = centre[1] + radius * math.sin(angle)
        # Draw the letter centred at its position
        text_w, text_h = draw.textsize(letter, font=font)
        draw.text((x - text_w / 2.0, y - text_h / 2.0), letter,
                  fill=letter_color, font=font)
        points.append((x, y))

    # Draw the connecting lines according to the selected shape
    if shape == 'polyline':
        # Join points in sequence, leaving the last point unconnected
        draw.line(points, fill=line_color, width=3)
    elif shape == 'star' and n > 2:
        # Connect every second point to form a star (skip = 2)
        skip = 2
        star_points = [points[i % n] for i in range(0, n * skip, skip)]
        draw.line(star_points + [star_points[0]], fill=line_color, width=3)
    else:
        # Default: connect all points and return to start (circle)
        draw.line(points + [points[0]], fill=line_color, width=3)

    return img


@app.route('/', methods=['GET', 'POST'])
def index():
    """Render the main page and handle sigil creation requests."""
    sigil_filename = None
    error = None
    if request.method == 'POST':
        phrase = request.form.get('phrase', '').strip()
        shape = request.form.get('shape', 'circle')
        line_color = request.form.get('line_color', 'red')
        letter_color = request.form.get('letter_color', 'white')
        if not phrase:
            error = 'Please enter a phrase to generate your sigil.'
        else:
            img = generate_sigil(phrase, shape, line_color, letter_color)
            if img:
                # Save with a unique filename
                filename = f'sigil_{uuid.uuid4().hex[:8]}.png'
                filepath = os.path.join(SIGIL_DIR, filename)
                img.save(filepath)
                sigil_filename = filename
            else:
                error = 'Unable to generate sigil. Please ensure the phrase contains alphabetic characters.'
    # Render the form page with the resulting image (if any)
    return render_template('index.html', sigil_filename=sigil_filename, error=error)


@app.route('/sigils/<path:filename>')
def serve_sigil(filename: str):
    """Serve a generated sigil from the ``static/sigils`` directory."""
    return send_from_directory(SIGIL_DIR, filename)


if __name__ == '__main__':
    # Only run the development server if executed directly. When
    # deployed on Replit, ``app.run`` will be called by the entrypoint.
    port = int(os.environ.get('PORT', 81))
    app.run(host='0.0.0.0', port=port, debug=True)