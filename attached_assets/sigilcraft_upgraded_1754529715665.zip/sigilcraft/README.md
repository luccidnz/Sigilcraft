# Sigil Craft Generator

Turn your intentions and desires into powerful, custom sigils using a web
interface. This application takes a phrase, removes duplicate letters,
lays the unique characters evenly around a circle and connects them to
form a unique glyph. You can customise the connecting pattern and
colours, then download your sigil for use in art, rituals or wherever
you need a little extra magick.

## Features

* **Web‑based UI** – no terminal required. Enter your phrase in a form and
  click a button to generate a sigil.
* **Custom shapes** – choose between a closed circle, open polyline or
  star connection pattern.
* **Colour options** – adjust line and letter colours using a colour
  picker.
* **Automatic file management** – generated images are saved with unique
  filenames in `static/sigils` for easy retrieval.
* **Mobile friendly** – responsive styling ensures the app works well on
  phones and tablets.

## Installation

1. Clone this repository or download the `sigilcraft` folder.
2. Install the dependencies. Using Python 3.8+ is recommended:

   ```bash
   pip install -r requirements.txt
   ```

## Usage

Run the Flask app from within the `sigilcraft` directory:

```bash
python app.py
```

By default the server will start on port `81`. Open your browser and
navigate to `http://localhost:81` (or the address displayed) to access
the UI. Enter your phrase, select your options and generate your
sigil. Click the download link to save the image.

When deploying on Replit or another host, ensure that the `static/sigils`
directory is persistent so generated images are retained.

## Testing

The application is simple but robust. To test locally, run the server
and try generating sigils with various phrases, including edge cases
(empty input, numbers and symbols, long phrases, etc.). Verify that
error messages appear appropriately and that the output image updates
with your selected options.

## License

This project is provided under the MIT License. See `LICENSE` for
details.